dhtmlxTree v.2.1 Standard edition build 90226

(c) DHTMLX Ltd. 

What's new in v.2.1 build 90226:

+ IE8 support

* look of editor in tree slightly improved
* dhx_globalImgPath added as default source for image path
* in path generation encodeURI changed to encodeURIcomponent 
* fixed behavior of call attribute, now it only call related event and not change selection in grid
* point of onOpenEnd event for dyn. loading scenario changed, so it occurs after item in question really expanded

- fixed situation when both text attribute and itemtext sub tag not specified for the item. 
- fixed issue with loading flag and open all items functionality 
- fixed error message in IE in case of HTTPS mode
- fixed hasChildren method for dyn. loading cases
- fixed issue caused by document.write usage, styles moved to default css file
- getSubItems uses global delimeter instead of hardcoded one
- fixed issue with incorrect context menu position
- fixed issue with incorrect item adding for dyn. branches in standard edition
- fixed issue with onXLE event missed after xml loading error
- fixed size of editor
- incorrect tree object reference fixed
- fixed regression with incorrect itemId in integrated context menu
- fixed issue with acessing nodes in smartXMLParsing mode while using json loading type
- fixed issue with incorrect auto-scrolling after mouse click in keyboard navigation mode
- fixed issue with using dyn. loading mode and "open" attribute in XML in same time

