dhtmlxConnector for PHP v.0.9 build 90226

(c) DHTMLX Ltd. 