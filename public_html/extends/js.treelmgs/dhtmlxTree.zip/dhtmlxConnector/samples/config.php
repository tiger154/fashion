<?php
	$mysql_server="localhost";
	$mysql_user = "root";
	$mysql_pass = "";
	$mysql_db = "sampleDB";
	
	$postrgre_connection = "host=localhost port=5432 dbname=sampleDB user=root password=1234";
?>